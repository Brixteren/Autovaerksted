﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BilVærk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void KundeBtn_Click(object sender, EventArgs e)
        {
            KundeForm kf = new KundeForm();

            kf.Top = this.Top;
            kf.Left = this.Left;

            this.Hide();
            kf.ShowDialog();
            this.Close();
        }

        private void BilBtn_Click(object sender, EventArgs e)
        {
            MenuTilBilForm mtbf = new MenuTilBilForm();

            mtbf.Top = this.Top;
            mtbf.Left = this.Left;

            this.Hide();
            mtbf.ShowDialog();
            this.Close();
        }

        private void OrdreBtn_Click(object sender, EventArgs e)
        {
            OrdreForm of = new OrdreForm();

            of.Top = this.Top;
            of.Left = this.Left;

            this.Hide();
            of.ShowDialog();
            this.Close();
        }
    }
}
