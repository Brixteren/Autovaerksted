﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsoleApp15;

namespace BilVærk
{
    public partial class MenuTilBilForm : Form
    {
        int kundeID;
        public MenuTilBilForm()
        {
            InitializeComponent();

            string[] input = { "" };

            SqlProgram sql = new SqlProgram();
            DataTable dt = sql.sqlConnection("k","v",input);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            string[] input = { "" };

            SqlProgram sql = new SqlProgram();
            DataTable dt = sql.sqlConnection("k", "v", input);
            kundeID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);

            BilForm bf = new BilForm(kundeID);

            bf.Top = this.Top;
            bf.Left = this.Left;

            this.Hide();
            bf.ShowDialog();
            this.Close();
        }
    }
}
