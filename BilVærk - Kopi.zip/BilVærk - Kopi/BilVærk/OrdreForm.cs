﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsoleApp15;

namespace BilVærk
{
    public partial class OrdreForm : Form
    {

        int kundeID, bilID, ordreID;

        public OrdreForm( int _kundeID)
        {
            kundeID = _kundeID;

            InitializeComponent();

            string[] input = { "" };

            SqlProgram sql = new SqlProgram();

            dataGridView1.DataSource = sql.sqlConnection("o", "v", input);

            DataTable dt = new DataTable();

            dt = sql.sqlConnection("k", "v", input);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if(dt.Rows[i].Field<int>("kundeID") == kundeID)
                {
                    kundeIdCB.Text = dt.Rows[i].Field<int>("kundeID").ToString() + " - " + dt.Rows[i].Field<string>("kundeFornavn") + " " + dt.Rows[i].Field<string>("kundeEfternavn");
                    break;
                }
            }
        }
        public OrdreForm()
        {
            InitializeComponent();

            string[] input = { "" };

            SqlProgram sql = new SqlProgram();

            dataGridView1.DataSource = sql.sqlConnection("o", "v", input);

            DataTable dt = new DataTable();

            dt = sql.sqlConnection("k", "v", input);

            kundeIdCB.Text = dt.Rows[0].Field<int>("kundeID").ToString() + " - " + dt.Rows[0].Field<string>("kundeFornavn") + " " + dt.Rows[0].Field<string>("kundeEfternavn");
            kundeID = dt.Rows[0].Field<int>("kundeID");
        }

        private void OpratOrdreBtn_Click(object sender, EventArgs e)
        {
            string[] para = new string[3];
            string[] kID = kundeIdCB.Text.Split('-');
            kID[0] = kID[0].Replace(" ", "");
            string[] bID = bilIdCB.Text.Split('-');
            bID[0] = bID[0].Replace(" ", "");


            SqlProgram sql = new SqlProgram();

            para[0] = kID[0];
            para[1] = bID[0];
            para[2] = problemTB.Text;

            sql.sqlConnection("o","o", para);

            para = new string[] { "" };

            dataGridView1.DataSource = sql.sqlConnection("o","v", para);
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            string[] para = { searchTB.Text };

            SqlProgram sql = new SqlProgram();
            dataGridView1.DataSource = sql.sqlConnection("o", "v", para);
        }

        private void kundeIdCB_DropDown(object sender, EventArgs e)
        {
            kundeIdCB.Items.Clear();

            string[] input = { "" };
            string textByg;
            SqlProgram sql = new SqlProgram();
            DataTable dt = new DataTable();

            dt = sql.sqlConnection("k", "v", input);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                textByg = "";
                textByg = dt.Rows[i].Field<int>("kundeID").ToString() + " - " + dt.Rows[i].Field<string>("kundeFornavn") + " " + dt.Rows[i].Field<string>("kundeEfternavn");

                kundeIdCB.Items.Add(textByg);
            }
        }

        private void kundeIdCB_SelectedValueChanged(object sender, EventArgs e)
        {
            string[] mellemRegning = kundeIdCB.Text.Split('-');

            kundeID = Convert.ToInt32(mellemRegning[0].Remove(mellemRegning[0].Length - 1, 1));

            bilIdCB.Text = "";
        }

        private void biIdCB_DropDown(object sender, EventArgs e)
        {
            bilIdCB.Items.Clear();

            string[] input = { "" };
            string textByg;
            SqlProgram sql = new SqlProgram();
            DataTable dt = new DataTable();

            dt = sql.sqlConnection("b", "v", input);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                textByg = "";

                if(dt.Rows[i].Field<int>("kundeID") == kundeID)
                {
                    textByg = dt.Rows[i].Field<int>("bilID").ToString() + " - " + dt.Rows[i].Field<string>("bilMærke") + " " + dt.Rows[i].Field<string>("bilModel");

                    bilIdCB.Items.Add(textByg);
                }
            }
        }

        private void bilIdCB_SelectedValueChanged(object sender, EventArgs e)
        {
            string[] mellemRegning = bilIdCB.Text.Split('-');

            bilID = Convert.ToInt32(mellemRegning[0].Remove(mellemRegning[0].Length - 1, 1));

            ordreIdCB.Text = "";
        }

        private void ordreIdCB_DropDown(object sender, EventArgs e)
        {
            ordreIdCB.Items.Clear();

            string[] input = { "" };
            string textByg;
            SqlProgram sql = new SqlProgram();
            DataTable dt = new DataTable();

            dt = sql.sqlConnection("o", "v", input);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                textByg = "";

                if (dt.Rows[i].Field<int>("bilID") == bilID)
                {
                    textByg = dt.Rows[i].Field<int>("ordreID").ToString() + " - " + dt.Rows[i].Field<DateTime>("dato").ToString();
                    textByg = textByg.Remove(textByg.Length -9, 9);

                    ordreIdCB.Items.Add(textByg);
                }
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ordreID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
        }

        private void sletBtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Er du sikker på du vil slette ordre nummer " + ordreID + "?", "Advarsel!", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                string[] para = new string[1];
                para[0] = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

                dataGridView1.Rows.Remove(dataGridView1.SelectedRows[0]);

                SqlProgram sql = new SqlProgram();

                sql.sqlConnection("o", "s", para);
            }
        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();

            this.Hide();
            f.ShowDialog();
            this.Close();
        }
    }
}
