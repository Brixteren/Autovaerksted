﻿namespace BilVærk
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.KundeBtn = new System.Windows.Forms.Button();
            this.BilBtn = new System.Windows.Forms.Button();
            this.OrdreBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // KundeBtn
            // 
            this.KundeBtn.Location = new System.Drawing.Point(13, 12);
            this.KundeBtn.Name = "KundeBtn";
            this.KundeBtn.Size = new System.Drawing.Size(171, 130);
            this.KundeBtn.TabIndex = 0;
            this.KundeBtn.Text = "Kunde";
            this.KundeBtn.UseVisualStyleBackColor = true;
            this.KundeBtn.Click += new System.EventHandler(this.KundeBtn_Click);
            // 
            // BilBtn
            // 
            this.BilBtn.Location = new System.Drawing.Point(191, 12);
            this.BilBtn.Name = "BilBtn";
            this.BilBtn.Size = new System.Drawing.Size(171, 129);
            this.BilBtn.TabIndex = 1;
            this.BilBtn.Text = "Biler";
            this.BilBtn.UseVisualStyleBackColor = true;
            this.BilBtn.Click += new System.EventHandler(this.BilBtn_Click);
            // 
            // OrdreBtn
            // 
            this.OrdreBtn.Location = new System.Drawing.Point(12, 151);
            this.OrdreBtn.Name = "OrdreBtn";
            this.OrdreBtn.Size = new System.Drawing.Size(349, 130);
            this.OrdreBtn.TabIndex = 2;
            this.OrdreBtn.Text = "Ordre";
            this.OrdreBtn.UseVisualStyleBackColor = true;
            this.OrdreBtn.Click += new System.EventHandler(this.OrdreBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 293);
            this.Controls.Add(this.OrdreBtn);
            this.Controls.Add(this.BilBtn);
            this.Controls.Add(this.KundeBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button KundeBtn;
        private System.Windows.Forms.Button BilBtn;
        private System.Windows.Forms.Button OrdreBtn;
    }
}

