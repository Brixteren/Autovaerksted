﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data.SqlClient;
using System.Data;

namespace ConsoleApp15
{
    class SqlProgram
    {
        public DataTable sqlConnection(string t, string c, string[] p)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = "Server = localhost; Database = Auto; Trusted_Connection = True";
                    conn.Open();

                    string stringComm;
                    SqlCommand command = new SqlCommand();

                    if (t == "k") // Kunder
                    {
                        if (c == "v") // Vis kunder
                        {
                            if (p[0] != "") // Vis kunder med parametre
                            {
                                stringComm = "SELECT * FROM Kunde WHERE kundeFornavn LIKE '%" + p[0] + "%' OR KundeEfternavn LIKE '%" + p[0] + "%' OR kundeAdresse LIKE '%" + p[0] + "%'";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("\'% @1 %\'", p[0]));
                                 return sqlReader(command);

                            }
                            else // Vis alle kunder
                            {
                                //conn.Open();
                                command = new SqlCommand("SELECT * FROM Kunde", conn);
                                return sqlReader(command);
                            }
                        }
                        else if (c == "o") // Opret kunder
                        {
                            if (p[0] != "")
                            {
                                stringComm = "INSERT INTO Kunde(kundeFornavn, kundeEfternavn, kundeAdresse) values ('" + p[0] + "', '" + p[1] +"', '" + p[2] +"', GETDATE())";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));
                                //command.Parameters.Add(new SqlParameter("2", p[1]));
                                //command.Parameters.Add(new SqlParameter("3", p[2]));

                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");
                                return sqlReader(command);
                            }
                        }
                        else if (c == "s") // Slet kunde
                        {
                            if (p[0] != "")
                            {
                                stringComm = "DELETE Ordre where kundeID = " + p[0] + "DELETE Biler where kundeID = " + p[0] + "; DELETE Kunde WHERE kundeID = " + p[0] + "";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));

                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");
                                return sqlReader(command);
                            }
                        }
                        else if (c == "u") // Opdater kunde
                        {
                            if (p[0] != "")
                            {
                                stringComm = "update Kunde set kundeFornavn = '" + p[1] +"', kundeEfternavn = '" + p[2] +"', kundeAdresse = '" + p[3] +"' where kundeID = " + p[0] +"";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));
                                //command.Parameters.Add(new SqlParameter("2", p[1]));
                                //command.Parameters.Add(new SqlParameter("3", p[2]));

                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");

                                return sqlReader(command);
                            }
                        }
                    }

                    if (t == "b") // Biler
                    {
                        if (c == "v") // Vis biler
                        {
                            if (p[0] != "") // Vis biler med parametre
                            {
                                stringComm = "SELECT * FROM Biler WHERE bilRegNR LIKE '%" + p[0] + "%'OR bilMærke LIKE '%" + p[0] + "%'OR bilModel LIKE '%" + p[0] + "%'OR bilAargang LIKE '%" + p[0] + "%'OR bilBraendstof LIKE '%" + p[0] + "%'";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));
                                return sqlReader(command);

                            }
                            else // Vis alle biler
                            {
                                command = new SqlCommand("SELECT * FROM Biler", conn);
                                return sqlReader(command);
                            }
                        }
                        else if (c == "o") // Opret bil
                        {
                            if (p[0] != "")
                            {
                                stringComm = "INSERT INTO Biler(kundeID, bilRegNr, bilMærke, bilModel, bilAargang, bilKm, bilBraendstof) values ("+ p[0] + ", " + p[1] + ", '" + p[2] + "', '" + p[3] + "', " + p[4] + ", " + p[5] + ", '" + p[6] + "', GETDATE())";
                                command = new SqlCommand(stringComm, conn);
                                /*
                                command.Parameters.Add(new SqlParameter("1", p[0]));
                                command.Parameters.Add(new SqlParameter("2", p[1]));
                                command.Parameters.Add(new SqlParameter("3", p[2]));
                                command.Parameters.Add(new SqlParameter("4", p[3]));
                                command.Parameters.Add(new SqlParameter("5", p[4]));
                                command.Parameters.Add(new SqlParameter("6", p[5]));
                                command.Parameters.Add(new SqlParameter("7", p[6]));
                                */
                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");

                                return sqlReader(command);
                            }
                        }
                        else if (c == "s") // Slet bil
                        {
                            if (p[0] != "")
                            {
                                stringComm = "DELETE Ordre where bilID = " + p[0] + "; DELETE Biler WHERE bilID = " + p[0] + "";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));

                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");

                                return sqlReader(command);
                            }
                        }
                        else if (c == "u") // Opdater bil
                        {
                            if (p[0] != "")
                            {
                                stringComm = "UPDATE Biler SET @1 = @2 WHERE bilID = @3";
                                command = new SqlCommand(stringComm, conn);
                                command.Parameters.Add(new SqlParameter("1", p[0]));
                                command.Parameters.Add(new SqlParameter("2", p[1]));
                                command.Parameters.Add(new SqlParameter("3", p[2]));

                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");

                                return sqlReader(command);
                            }
                        }
                    }

                    if (t == "o") // Værkstedsbesøg
                    {
                        if (c == "v") // Vis værkstedsbesøg
                        {
                            if (p[0] != "") // Vis værkstedsbesøg med parametre
                            {
                                stringComm = "SELECT * FROM Ordre WHERE ordreID LIKE '%" + p[0] + "%' OR kundeID LIKE '%" + p[0] + "%' OR bilID LIKE '%" + p[0] + "%' OR problem LIKE '%" + p[0] + "%' OR dato LIKE '%" + p[0] + "%'";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));
                                return sqlReader(command);

                            }
                            else // Vis alle værkstedsbesøg
                            {
                                command = new SqlCommand("SELECT * FROM Ordre", conn);
                                return sqlReader(command);
                            }
                        }
                        else if (c == "o") // Opret værkstedsbesøg
                        {
                            if (p[0] != "")
                            {
                                stringComm = "INSERT INTO Ordre(kundeID, bilID, problem, dato) values ('"+ p[0] + "', '" + p[1] + "', '" + p[2] +"', GETDATE())";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));
                                //command.Parameters.Add(new SqlParameter("2", p[1]));
                                //command.Parameters.Add(new SqlParameter("3", p[2]));

                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");

                                return sqlReader(command);
                            }
                        }
                        else if (c == "s") // Slet værkstedsbesøg
                        {
                            if (p[0] != "")
                            {
                                stringComm = "DELETE Ordre WHERE ordreID = " + p[0] +"";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));

                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");

                                return sqlReader(command);
                            }
                        }
                        else if (c == "u") // Opdater værkstedsbesøg
                        {
                            if (p[0] != "")
                            {
                                stringComm = "UPDATE Ordre SET " + p[0] +" = " + p[1] + " WHERE ordreID = " + p[2] +"";
                                command = new SqlCommand(stringComm, conn);
                                //command.Parameters.Add(new SqlParameter("1", p[0]));
                                //command.Parameters.Add(new SqlParameter("2", p[1]));
                                //command.Parameters.Add(new SqlParameter("3", p[2]));

                                return sqlReader(command);
                            }
                            else
                            {
                                Console.WriteLine("Du har ikke sendt nogle parametre med");

                                return sqlReader(command);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return new DataTable();
        }

        public DataTable sqlReader(SqlCommand i)
        {
            DataTable output = new DataTable();
            using (SqlDataReader reader = i.ExecuteReader())
            {
                //while (reader.Read())
                //{
                    output.Load(reader);
                //}
            }

            return output;
        }
    }
}