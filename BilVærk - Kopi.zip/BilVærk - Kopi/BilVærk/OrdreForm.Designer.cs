﻿namespace BilVærk
{
    partial class OrdreForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchBtn = new System.Windows.Forms.Button();
            this.searchTB = new System.Windows.Forms.TextBox();
            this.problemTB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.OpratOrdreBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.sletBtn = new System.Windows.Forms.Button();
            this.menuBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.kundeIdCB = new System.Windows.Forms.ComboBox();
            this.bilIdCB = new System.Windows.Forms.ComboBox();
            this.ordreIdCB = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // searchBtn
            // 
            this.searchBtn.Location = new System.Drawing.Point(262, 12);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(75, 23);
            this.searchBtn.TabIndex = 50;
            this.searchBtn.Text = "Søg";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // searchTB
            // 
            this.searchTB.Location = new System.Drawing.Point(343, 12);
            this.searchTB.Name = "searchTB";
            this.searchTB.Size = new System.Drawing.Size(283, 22);
            this.searchTB.TabIndex = 49;
            // 
            // problemTB
            // 
            this.problemTB.Location = new System.Drawing.Point(12, 244);
            this.problemTB.Multiline = true;
            this.problemTB.Name = "problemTB";
            this.problemTB.Size = new System.Drawing.Size(241, 161);
            this.problemTB.TabIndex = 48;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 222);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 17);
            this.label7.TabIndex = 47;
            this.label7.Text = "Problem";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 39;
            this.label2.Text = "Bil ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 36;
            this.label1.Text = "Kunde ID";
            // 
            // OpratOrdreBtn
            // 
            this.OpratOrdreBtn.Location = new System.Drawing.Point(12, 12);
            this.OpratOrdreBtn.Name = "OpratOrdreBtn";
            this.OpratOrdreBtn.Size = new System.Drawing.Size(241, 58);
            this.OpratOrdreBtn.TabIndex = 35;
            this.OpratOrdreBtn.Text = "Opret Ordre";
            this.OpratOrdreBtn.UseVisualStyleBackColor = true;
            this.OpratOrdreBtn.Click += new System.EventHandler(this.OpratOrdreBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(-2, 408);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(258, 17);
            this.label4.TabIndex = 34;
            this.label4.Text = "--------------------------------------------------";
            // 
            // sletBtn
            // 
            this.sletBtn.Location = new System.Drawing.Point(12, 428);
            this.sletBtn.Name = "sletBtn";
            this.sletBtn.Size = new System.Drawing.Size(241, 37);
            this.sletBtn.TabIndex = 33;
            this.sletBtn.Text = "Slet";
            this.sletBtn.UseVisualStyleBackColor = true;
            this.sletBtn.Click += new System.EventHandler(this.sletBtn_Click);
            // 
            // menuBtn
            // 
            this.menuBtn.Location = new System.Drawing.Point(12, 488);
            this.menuBtn.Name = "menuBtn";
            this.menuBtn.Size = new System.Drawing.Size(244, 74);
            this.menuBtn.TabIndex = 32;
            this.menuBtn.Text = "Menu";
            this.menuBtn.UseVisualStyleBackColor = true;
            this.menuBtn.Click += new System.EventHandler(this.menuBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(262, 40);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(790, 522);
            this.dataGridView1.TabIndex = 31;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // kundeIdCB
            // 
            this.kundeIdCB.FormattingEnabled = true;
            this.kundeIdCB.Location = new System.Drawing.Point(12, 94);
            this.kundeIdCB.Name = "kundeIdCB";
            this.kundeIdCB.Size = new System.Drawing.Size(241, 24);
            this.kundeIdCB.TabIndex = 51;
            this.kundeIdCB.DropDown += new System.EventHandler(this.kundeIdCB_DropDown);
            this.kundeIdCB.SelectedValueChanged += new System.EventHandler(this.kundeIdCB_SelectedValueChanged);
            // 
            // bilIdCB
            // 
            this.bilIdCB.FormattingEnabled = true;
            this.bilIdCB.Location = new System.Drawing.Point(12, 145);
            this.bilIdCB.Name = "bilIdCB";
            this.bilIdCB.Size = new System.Drawing.Size(241, 24);
            this.bilIdCB.TabIndex = 52;
            this.bilIdCB.DropDown += new System.EventHandler(this.biIdCB_DropDown);
            this.bilIdCB.SelectedValueChanged += new System.EventHandler(this.bilIdCB_SelectedValueChanged);
            // 
            // ordreIdCB
            // 
            this.ordreIdCB.FormattingEnabled = true;
            this.ordreIdCB.Location = new System.Drawing.Point(12, 195);
            this.ordreIdCB.Name = "ordreIdCB";
            this.ordreIdCB.Size = new System.Drawing.Size(241, 24);
            this.ordreIdCB.TabIndex = 53;
            this.ordreIdCB.DropDown += new System.EventHandler(this.ordreIdCB_DropDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 54;
            this.label3.Text = "Ordre ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-2, 468);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(258, 17);
            this.label5.TabIndex = 55;
            this.label5.Text = "--------------------------------------------------";
            // 
            // OrdreForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 574);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ordreIdCB);
            this.Controls.Add(this.bilIdCB);
            this.Controls.Add(this.kundeIdCB);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.searchTB);
            this.Controls.Add(this.problemTB);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OpratOrdreBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.sletBtn);
            this.Controls.Add(this.menuBtn);
            this.Controls.Add(this.dataGridView1);
            this.Name = "OrdreForm";
            this.Text = "OrdreForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.TextBox searchTB;
        private System.Windows.Forms.TextBox problemTB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button OpratOrdreBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button sletBtn;
        private System.Windows.Forms.Button menuBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox kundeIdCB;
        private System.Windows.Forms.ComboBox bilIdCB;
        private System.Windows.Forms.ComboBox ordreIdCB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
    }
}