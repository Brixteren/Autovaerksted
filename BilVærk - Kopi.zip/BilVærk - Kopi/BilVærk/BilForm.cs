﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsoleApp15;

namespace BilVærk
{
    public partial class BilForm : Form
    {
        int kundeID;
        int bilID;

        public BilForm (int _kundeID)
        {
            kundeID = _kundeID;
            string[] input = { "" };

            InitializeComponent();

            SqlProgram sql = new SqlProgram();
            dataGridView1.DataSource = sql.sqlConnection("b","v", input);
            DataTable dt = new DataTable();
            dt = sql.sqlConnection("k","v", input);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i].Field<int>("kundeID") == kundeID)
                {
                    valgtBrugerCB.Text = dt.Rows[i].Field<int>("kundeID").ToString() + " - " + dt.Rows[i].Field<string>("kundeFornavn") + " " + dt.Rows[i].Field<string>("kundeEfternavn");
                    break;
                }
            }

            //valgtBrugerCB.Text = dataGridView1.
        }

        private void OpratBilBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //new user info instaniation og tjæk for om info textbox er "" eller " "
                //kaster exeption vis sandt
                string[] nyBruger = {
                    kundeID.ToString(),
                    BilRegNrTB.Text != "" && BilRegNrTB.Text != " "? BilRegNrTB.Text : throw new Exception(),
                    bilMærkeTB.Text != "" && bilMærkeTB.Text != " "? bilMærkeTB.Text : throw new Exception(),
                    bilModelTB.Text != "" && bilModelTB.Text != " "? bilModelTB.Text : throw new Exception(),
                    bilÅrgangTB.Text != "" && bilÅrgangTB.Text != " " ? bilÅrgangTB.Text : throw new Exception(),
                kørteKmTB.Text != "" && kørteKmTB.Text != " " ? kørteKmTB.Text : throw new Exception(),
                brændstofTypeCB.Text != "" && brændstofTypeCB.Text != " " ? brændstofTypeCB.Text : throw new Exception()
                };

                SqlProgram sql = new SqlProgram();

                sql.sqlConnection("b", "o", nyBruger);

                string[] para = { "" };

                DataTable dt = sql.sqlConnection("b", "v", para);

                bilID = dt.Rows[dt.Rows.Count - 1].Field<int>("bilID");

                MessageBox.Show("Bil er oprattet \r\nVi tager dig til Ordre vinduet nu", "Form Closing", MessageBoxButtons.OK);

                OrdreForm of = new OrdreForm(kundeID);

                of.Top = this.Top;
                of.Left = this.Left;

                this.Hide();
                of.ShowDialog();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alle felter skal være udfyldt");
            }
        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();

            this.Hide();
            f.ShowDialog();
            this.Close();
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            string[] para = { searchTB.Text };

            SqlProgram sql = new SqlProgram();
            dataGridView1.DataSource = sql.sqlConnection("b", "v", para);
        }

        private void sletBtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Er du sikker på du vil slette den valgte bil?", "Advarsel!", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                string[] para = new string[1];
                para[0] = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

                dataGridView1.Rows.Remove(dataGridView1.SelectedRows[0]);

                SqlProgram sql = new SqlProgram();

                sql.sqlConnection("b", "s", para);
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            BilRegNrTB.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            bilMærkeTB.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            bilModelTB.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            bilÅrgangTB.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            kørteKmTB.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            brændstofTypeCB.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
        }

        private void valgtBrugerCB_DropDown(object sender, EventArgs e)
        {
            string[] input = { "" };
            string textByg;
            SqlProgram sql = new SqlProgram();
            DataTable dt = new DataTable();

            dt = sql.sqlConnection("k","v", input);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                textByg = "";
                textByg = dt.Rows[i].Field<int>("kundeID").ToString() + " - " + dt.Rows[i].Field<string>("kundeFornavn") + " " + dt.Rows[i].Field<string>("kundeEfternavn");

                valgtBrugerCB.Items.Add(textByg);
            }
        }

        private void valgtBrugerCB_Click(object sender, EventArgs e)
        {
            string[] mellemRegning = valgtBrugerCB.Text.Split('-');

            kundeID = Convert.ToInt32(mellemRegning[0].Remove(mellemRegning[0].Length -1, 1));
        }
    }
}
