﻿namespace BilVærk
{
    partial class KundeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.OpratKundeBtn = new System.Windows.Forms.Button();
            this.MenuBtn = new System.Windows.Forms.Button();
            this.forNavnTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.efterNavnTB = new System.Windows.Forms.TextBox();
            this.adresseTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SearchTB = new System.Windows.Forms.TextBox();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.sletBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.UpdateKundeBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(262, 40);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(790, 522);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // OpratKundeBtn
            // 
            this.OpratKundeBtn.Location = new System.Drawing.Point(14, 40);
            this.OpratKundeBtn.Name = "OpratKundeBtn";
            this.OpratKundeBtn.Size = new System.Drawing.Size(112, 47);
            this.OpratKundeBtn.TabIndex = 1;
            this.OpratKundeBtn.Text = "Opret Kunde";
            this.OpratKundeBtn.UseVisualStyleBackColor = true;
            this.OpratKundeBtn.Click += new System.EventHandler(this.OpratKundeBtn_Click);
            // 
            // MenuBtn
            // 
            this.MenuBtn.Location = new System.Drawing.Point(12, 455);
            this.MenuBtn.Name = "MenuBtn";
            this.MenuBtn.Size = new System.Drawing.Size(244, 107);
            this.MenuBtn.TabIndex = 2;
            this.MenuBtn.Text = "Menu";
            this.MenuBtn.UseVisualStyleBackColor = true;
            this.MenuBtn.Click += new System.EventHandler(this.MenuBtn_Click);
            // 
            // forNavnTB
            // 
            this.forNavnTB.Location = new System.Drawing.Point(14, 110);
            this.forNavnTB.Name = "forNavnTB";
            this.forNavnTB.Size = new System.Drawing.Size(244, 22);
            this.forNavnTB.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Fornavn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Efternavn";
            // 
            // efterNavnTB
            // 
            this.efterNavnTB.Location = new System.Drawing.Point(14, 170);
            this.efterNavnTB.Name = "efterNavnTB";
            this.efterNavnTB.Size = new System.Drawing.Size(244, 22);
            this.efterNavnTB.TabIndex = 6;
            // 
            // adresseTB
            // 
            this.adresseTB.Location = new System.Drawing.Point(14, 230);
            this.adresseTB.Name = "adresseTB";
            this.adresseTB.Size = new System.Drawing.Size(244, 22);
            this.adresseTB.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Adresse";
            // 
            // SearchTB
            // 
            this.SearchTB.Location = new System.Drawing.Point(435, 11);
            this.SearchTB.Name = "SearchTB";
            this.SearchTB.Size = new System.Drawing.Size(207, 22);
            this.SearchTB.TabIndex = 9;
            // 
            // SearchBtn
            // 
            this.SearchBtn.Location = new System.Drawing.Point(262, 11);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(167, 23);
            this.SearchBtn.TabIndex = 10;
            this.SearchBtn.Text = "Søg";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // sletBtn
            // 
            this.sletBtn.Location = new System.Drawing.Point(12, 358);
            this.sletBtn.Name = "sletBtn";
            this.sletBtn.Size = new System.Drawing.Size(244, 74);
            this.sletBtn.TabIndex = 11;
            this.sletBtn.Text = "Slet";
            this.sletBtn.UseVisualStyleBackColor = true;
            this.sletBtn.Click += new System.EventHandler(this.sletBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(-2, 338);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(258, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "--------------------------------------------------";
            // 
            // UpdateKundeBtn
            // 
            this.UpdateKundeBtn.Location = new System.Drawing.Point(132, 40);
            this.UpdateKundeBtn.Name = "UpdateKundeBtn";
            this.UpdateKundeBtn.Size = new System.Drawing.Size(126, 47);
            this.UpdateKundeBtn.TabIndex = 13;
            this.UpdateKundeBtn.Text = "Opdater Kunde";
            this.UpdateKundeBtn.UseVisualStyleBackColor = true;
            this.UpdateKundeBtn.Click += new System.EventHandler(this.UpdateKundeBtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(0, 435);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(258, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "--------------------------------------------------";
            // 
            // KundeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 574);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.UpdateKundeBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.sletBtn);
            this.Controls.Add(this.SearchBtn);
            this.Controls.Add(this.SearchTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.adresseTB);
            this.Controls.Add(this.efterNavnTB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.forNavnTB);
            this.Controls.Add(this.MenuBtn);
            this.Controls.Add(this.OpratKundeBtn);
            this.Controls.Add(this.dataGridView1);
            this.Name = "KundeForm";
            this.Text = "KundeForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button OpratKundeBtn;
        private System.Windows.Forms.Button MenuBtn;
        private System.Windows.Forms.TextBox forNavnTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox efterNavnTB;
        private System.Windows.Forms.TextBox adresseTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox SearchTB;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.Button sletBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button UpdateKundeBtn;
        private System.Windows.Forms.Label label5;
    }
}