﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsoleApp15;

namespace BilVærk
{
    public partial class KundeForm : Form
    {

        int kundeID;
        public KundeForm()
        {
            InitializeComponent();
            //tom array for at ramme else i Sqlconnect methode
            string[] para = { "" }; 

            SqlProgram sql = new SqlProgram();
            
            dataGridView1.DataSource = sql.sqlConnection("k", "v", para);
        }

        private void MenuBtn_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();

            f.Top = this.Top;
            f.Left = this.Left;

            this.Hide();
            f.ShowDialog();
            this.Close();
        }

        

        private void OpratKundeBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //new user info instaniation og tjæk for om info textbox er "" eller " "
                //kaster exeption vis sandt
                string[] nyBruger = {
                    forNavnTB.Text != "" && forNavnTB.Text != " "? forNavnTB.Text : throw new Exception(),
                    efterNavnTB.Text != "" && efterNavnTB.Text != " "? efterNavnTB.Text : throw new Exception(),
                    adresseTB.Text != "" && adresseTB.Text != " " ? adresseTB.Text : throw new Exception() };

                SqlProgram sql = new SqlProgram();

                sql.sqlConnection("k","o",nyBruger);

                string[] para = { "" };

                DataTable dt = sql.sqlConnection("k", "v", para);

                kundeID = dt.Rows[dt.Rows.Count-1].Field<int>("KundeID");

                MessageBox.Show("Kunde er oprattet \r\nVi tager dig til Bil vinduet nu", "Form Closing", MessageBoxButtons.OK);

                BilForm bf = new BilForm(kundeID);

                bf.Top = this.Top;
                bf.Left = this.Left;

                this.Hide();
                bf.ShowDialog();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alle felter skal være udfyldt");
            }
            
        }
        private void SearchBtn_Click(object sender, EventArgs e)
        {
            string[] para = { SearchTB.Text };

            SqlProgram sql = new SqlProgram();
            dataGridView1.DataSource = sql.sqlConnection("k","v",para);
        }

        private void sletBtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Er du sikker på du vil slette " + forNavnTB.Text + " " + efterNavnTB.Text + " (" + kundeID + ")?", "Advarsel!", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                string[] para = new string[1];
                para[0] = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

                dataGridView1.Rows.Remove(dataGridView1.SelectedRows[0]);

                SqlProgram sql = new SqlProgram();

                sql.sqlConnection("k","s", para);
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            kundeID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);

            forNavnTB.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            efterNavnTB.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            adresseTB.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void UpdateKundeBtn_Click(object sender, EventArgs e)
        {
            string[] userInfo = {
                dataGridView1.SelectedRows[0].Cells[0].Value.ToString(),
                forNavnTB.Text, efterNavnTB.Text, adresseTB.Text
            };

            SqlProgram sql = new SqlProgram();
            sql.sqlConnection("k","u",userInfo);

            string[] para = { "" };
            //reload data for datagridview
            dataGridView1.DataSource = sql.sqlConnection("k", "v", para);
        }
    }
}
