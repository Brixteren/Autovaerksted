﻿namespace BilVærk
{
    partial class BilForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuBtn = new System.Windows.Forms.Button();
            this.sletBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.OpratBilBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BilRegNrTB = new System.Windows.Forms.TextBox();
            this.bilMærkeTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bilÅrgangTB = new System.Windows.Forms.TextBox();
            this.kørteKmTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.brændstofTypeCB = new System.Windows.Forms.ComboBox();
            this.OpdaterBilBtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.bilModelTB = new System.Windows.Forms.TextBox();
            this.searchTB = new System.Windows.Forms.TextBox();
            this.searchBtn = new System.Windows.Forms.Button();
            this.valgtBrugerCB = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(262, 40);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(790, 522);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // menuBtn
            // 
            this.menuBtn.Location = new System.Drawing.Point(12, 513);
            this.menuBtn.Name = "menuBtn";
            this.menuBtn.Size = new System.Drawing.Size(244, 49);
            this.menuBtn.TabIndex = 1;
            this.menuBtn.Text = "Menu";
            this.menuBtn.UseVisualStyleBackColor = true;
            this.menuBtn.Click += new System.EventHandler(this.menuBtn_Click);
            // 
            // sletBtn
            // 
            this.sletBtn.Location = new System.Drawing.Point(12, 443);
            this.sletBtn.Name = "sletBtn";
            this.sletBtn.Size = new System.Drawing.Size(112, 37);
            this.sletBtn.TabIndex = 2;
            this.sletBtn.Text = "Slet";
            this.sletBtn.UseVisualStyleBackColor = true;
            this.sletBtn.Click += new System.EventHandler(this.sletBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(-2, 423);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(258, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "--------------------------------------------------";
            // 
            // OpratBilBtn
            // 
            this.OpratBilBtn.Location = new System.Drawing.Point(12, 89);
            this.OpratBilBtn.Name = "OpratBilBtn";
            this.OpratBilBtn.Size = new System.Drawing.Size(112, 47);
            this.OpratBilBtn.TabIndex = 14;
            this.OpratBilBtn.Text = "Opret Bil";
            this.OpratBilBtn.UseVisualStyleBackColor = true;
            this.OpratBilBtn.Click += new System.EventHandler(this.OpratBilBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "Bil reg Nr";
            // 
            // BilRegNrTB
            // 
            this.BilRegNrTB.Location = new System.Drawing.Point(12, 164);
            this.BilRegNrTB.Name = "BilRegNrTB";
            this.BilRegNrTB.Size = new System.Drawing.Size(241, 22);
            this.BilRegNrTB.TabIndex = 16;
            // 
            // bilMærkeTB
            // 
            this.bilMærkeTB.Location = new System.Drawing.Point(12, 209);
            this.bilMærkeTB.Name = "bilMærkeTB";
            this.bilMærkeTB.Size = new System.Drawing.Size(241, 22);
            this.bilMærkeTB.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 17);
            this.label2.TabIndex = 18;
            this.label2.Text = "Bil Mærke";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 284);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 17);
            this.label3.TabIndex = 19;
            this.label3.Text = "Bil årgang";
            // 
            // bilÅrgangTB
            // 
            this.bilÅrgangTB.Location = new System.Drawing.Point(12, 304);
            this.bilÅrgangTB.Name = "bilÅrgangTB";
            this.bilÅrgangTB.Size = new System.Drawing.Size(241, 22);
            this.bilÅrgangTB.TabIndex = 20;
            // 
            // kørteKmTB
            // 
            this.kørteKmTB.Location = new System.Drawing.Point(12, 349);
            this.kørteKmTB.Name = "kørteKmTB";
            this.kørteKmTB.Size = new System.Drawing.Size(241, 22);
            this.kørteKmTB.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 329);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 17);
            this.label5.TabIndex = 22;
            this.label5.Text = "Kørte KM";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 374);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 17);
            this.label6.TabIndex = 23;
            this.label6.Text = "Brændstof Type";
            // 
            // brændstofTypeCB
            // 
            this.brændstofTypeCB.FormattingEnabled = true;
            this.brændstofTypeCB.Items.AddRange(new object[] {
            "Benzin",
            "Diesel",
            "Elektricitet",
            "Hybrid"});
            this.brændstofTypeCB.Location = new System.Drawing.Point(12, 396);
            this.brændstofTypeCB.MaxLength = 200;
            this.brændstofTypeCB.Name = "brændstofTypeCB";
            this.brændstofTypeCB.Size = new System.Drawing.Size(241, 24);
            this.brændstofTypeCB.TabIndex = 24;
            // 
            // OpdaterBilBtn
            // 
            this.OpdaterBilBtn.Location = new System.Drawing.Point(128, 89);
            this.OpdaterBilBtn.Name = "OpdaterBilBtn";
            this.OpdaterBilBtn.Size = new System.Drawing.Size(125, 47);
            this.OpdaterBilBtn.TabIndex = 25;
            this.OpdaterBilBtn.Text = "Opdater Bil";
            this.OpdaterBilBtn.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 17);
            this.label7.TabIndex = 26;
            this.label7.Text = "Bil Model";
            // 
            // bilModelTB
            // 
            this.bilModelTB.Location = new System.Drawing.Point(12, 259);
            this.bilModelTB.Name = "bilModelTB";
            this.bilModelTB.Size = new System.Drawing.Size(241, 22);
            this.bilModelTB.TabIndex = 27;
            // 
            // searchTB
            // 
            this.searchTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchTB.Location = new System.Drawing.Point(343, 9);
            this.searchTB.Name = "searchTB";
            this.searchTB.Size = new System.Drawing.Size(283, 24);
            this.searchTB.TabIndex = 28;
            // 
            // searchBtn
            // 
            this.searchBtn.Location = new System.Drawing.Point(262, 9);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(75, 25);
            this.searchBtn.TabIndex = 29;
            this.searchBtn.Text = "Søg";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // valgtBrugerCB
            // 
            this.valgtBrugerCB.FormattingEnabled = true;
            this.valgtBrugerCB.Location = new System.Drawing.Point(12, 40);
            this.valgtBrugerCB.Name = "valgtBrugerCB";
            this.valgtBrugerCB.Size = new System.Drawing.Size(241, 24);
            this.valgtBrugerCB.TabIndex = 30;
            this.valgtBrugerCB.DropDown += new System.EventHandler(this.valgtBrugerCB_DropDown);
            this.valgtBrugerCB.SelectedValueChanged += new System.EventHandler(this.valgtBrugerCB_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 17);
            this.label8.TabIndex = 31;
            this.label8.Text = "Valgt kunde til oprettelse:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(-2, 483);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(258, 17);
            this.label9.TabIndex = 32;
            this.label9.Text = "--------------------------------------------------";
            // 
            // BilForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 574);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.valgtBrugerCB);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.searchTB);
            this.Controls.Add(this.bilModelTB);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.OpdaterBilBtn);
            this.Controls.Add(this.brændstofTypeCB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.kørteKmTB);
            this.Controls.Add(this.bilÅrgangTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bilMærkeTB);
            this.Controls.Add(this.BilRegNrTB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OpratBilBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.sletBtn);
            this.Controls.Add(this.menuBtn);
            this.Controls.Add(this.dataGridView1);
            this.Name = "BilForm";
            this.Text = "BilForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button menuBtn;
        private System.Windows.Forms.Button sletBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button OpratBilBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BilRegNrTB;
        private System.Windows.Forms.TextBox bilMærkeTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox bilÅrgangTB;
        private System.Windows.Forms.TextBox kørteKmTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox brændstofTypeCB;
        private System.Windows.Forms.Button OpdaterBilBtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox bilModelTB;
        private System.Windows.Forms.TextBox searchTB;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.ComboBox valgtBrugerCB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}